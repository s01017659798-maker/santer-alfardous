const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const root = path.resolve(__dirname, '..');
const html = fs.readFileSync(path.join(root, 'app/src/main/assets/index.html'), 'utf8');
const java = fs.readFileSync(path.join(root, 'app/src/main/java/eg/alfardous/center/MainActivity.java'), 'utf8');
const gradle = fs.readFileSync(path.join(root, 'app/build.gradle'), 'utf8');

test('all existing and newly created exams are limited to one attempt', () => {
  assert.match(html, /db\.exams\.forEach\(x=>\{x\.maxAttempts=1/);
  assert.match(html, /maxAttempts:1/);
  assert.match(html, /if\(used>=1\)/);
  assert.doesNotMatch(html, /maxAttempts:2|used>=2|length<\(ex\.maxAttempts\|\|2\)/);
});

test('teacher student list is scoped to assigned groups', () => {
  assert.match(html, /currentCenterAccount\?\.role==='teacher'[\s\S]{0,200}ids\.has\(String\(st\.groupId\)\)/);
  assert.match(html, /الطالب خارج المجموعات المسندة إليك/);
});

test('teacher cannot navigate to admin sections or record attendance outside assigned groups', () => {
  assert.match(html, /هذا القسم غير متاح لحساب المدرس/);
  assert.match(html, /لا يمكنك تسجيل الحضور لمجموعة غير مسندة إليك/);
});

test('student account is limited to its own portal and own record', () => {
  assert.match(html, /id\)===String\(currentCenterAccount\.personId\)/);
  assert.match(html, /حساب الطالب يعرض بياناته من بوابة الطالب فقط/);
});

test('administrative mutation entry points are guarded', () => {
  assert.match(html, /const managerOnly=\[/);
  assert.match(html, /هذه العملية متاحة للمدير فقط/);
});

test('WebView blocks non-app navigation from the privileged local page', () => {
  assert.match(java, /setAllowFileAccessFromFileURLs\(false\)/);
  assert.match(java, /setAllowUniversalAccessFromFileURLs\(false\)/);
  assert.match(java, /MIXED_CONTENT_NEVER_ALLOW/);
  assert.match(java, /block every other scheme\/navigation/);
  assert.match(java, /removeJavascriptInterface\("AndroidFileBridge"\)/);
});

test('new app identity and version are explicit', () => {
  assert.match(gradle, /applicationId 'eg\.alfardous\.center\.fresh'/);
  assert.match(gradle, /versionCode 387/);
  assert.match(gradle, /versionName '3\.8\.7'/);
});
