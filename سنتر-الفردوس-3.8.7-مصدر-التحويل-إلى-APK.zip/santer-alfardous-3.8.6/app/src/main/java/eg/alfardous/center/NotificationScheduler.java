package eg.alfardous.center;

import android.app.PendingIntent;
import android.app.AlarmManager;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import org.json.JSONArray;
import org.json.JSONObject;

public class NotificationScheduler {
    static final String PREFS = "alfardous_native_reminders";
    static final String CHANNEL = "alfardous_reminders";
    static void ensureChannel(Context c) {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel ch = new NotificationChannel(CHANNEL, "تذكيرات سنتر الفردوس", NotificationManager.IMPORTANCE_HIGH);
            ch.setDescription("تنبيهات مواعيد الحصص والامتحانات والتحصيل والمهام");
            ((NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE)).createNotificationChannel(ch);
        }
    }
    static PendingIntent pending(Context c, String id, long at, String title, String body, boolean weekly) {
        Intent i = new Intent(c, ReminderReceiver.class).setAction("eg.alfardous.center.REMINDER." + id);
        i.putExtra("id", id); i.putExtra("title", title); i.putExtra("body", body); i.putExtra("at", at); i.putExtra("weekly", weekly);
        return PendingIntent.getBroadcast(c, id.hashCode(), i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }
    static void schedule(Context c, JSONObject row) throws Exception {
        String id=row.getString("id"); long at=row.getLong("at"); if(at<=System.currentTimeMillis()) return;
        String title=row.optString("title", "سنتر الفردوس التعليمي"), body=row.optString("body", "لديك تذكير"); boolean weekly=row.optBoolean("weekly", false);
        AlarmManager am=(AlarmManager)c.getSystemService(Context.ALARM_SERVICE);
        am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pending(c,id,at,title,body,weekly));
        c.getSharedPreferences(PREFS,0).edit().putString(id,row.toString()).apply();
    }
    static void cancel(Context c, String id) {
        AlarmManager am=(AlarmManager)c.getSystemService(Context.ALARM_SERVICE);
        am.cancel(pending(c,id,0,"","",false));
        c.getSharedPreferences(PREFS,0).edit().remove(id).apply();
    }
    static void replaceAll(Context c, JSONArray rows) throws Exception {
        SharedPreferences sp=c.getSharedPreferences(PREFS,0);
        for(String key:sp.getAll().keySet()) cancel(c,key);
        for(int i=0;i<rows.length();i++) schedule(c,rows.getJSONObject(i));
    }
    static void restore(Context c) {
        ensureChannel(c); SharedPreferences sp=c.getSharedPreferences(PREFS,0);
        for(String key:sp.getAll().keySet()) { try { JSONObject row=new JSONObject(sp.getString(key,"{}")); long at=row.getLong("at"); if(at>System.currentTimeMillis()) schedule(c,row); else cancel(c,key); } catch(Exception ignored) { cancel(c,key); } }
    }
}
